const countryDetailsContainer = document.getElementById("country-details");

// Функция для получения параметра из URL
function getQueryParam(param) {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get(param);
}

// Функция для загрузки информации о стране
async function fetchCountryDetails() {
    try {
        const countryName = getQueryParam("name");
        const response = await fetch(`https://restcountries.com/v3.1/name/${countryName}`);
        const country = (await response.json())[0];
        displayCountryDetails(country);
    } catch (error) {
        console.error("Error:", error);
    }
}

function displayCountryDetails(country) {
    const countryName = country.name.common;

    countryDetailsContainer.innerHTML = `
        <h1>${countryName}</h1>
        <img src="${country.flags.svg}" alt="Flag" width="200">
        <p><strong>Capital:</strong> ${country.capital}</p>
        <p><strong>Population:</strong> ${country.population.toLocaleString()}</p>
        <p><strong>Region:</strong> ${country.region}</p>
        <p><strong>Subregion:</strong> ${country.subregion}</p>
        <p><strong>Languages:</strong> ${Object.values(country.languages).join(", ")}</p>
        <p><strong>Currency:</strong> ${Object.values(country.currencies)[0].name} (${Object.keys(country.currencies)[0]})</p>
        
        <a href="https://www.google.com/maps/search/${countryName}"  
           style="display:inline-block; margin-top:10px; color:blue; text-decoration:underline;">
            Посмотреть на карте
        </a>
    `;
}

// Функция для кнопки "Назад"
function goBack() {
    window.history.back();
}

// Загружаем данные о стране
fetchCountryDetails();
